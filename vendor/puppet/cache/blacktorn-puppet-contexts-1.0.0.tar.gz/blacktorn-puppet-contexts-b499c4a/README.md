# Contexts Puppet Module for Boxen

Install [Contexts](http://contextsformac.com/) on your Mac.

[![Build Status](https://travis-ci.org/boxen/puppet-template.png?branch=master)](https://travis-ci.org/boxen/puppet-template)

## Usage

```puppet
include contexts;
```

## Required Puppet Modules

* `boxen`

## Development

Write some code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
