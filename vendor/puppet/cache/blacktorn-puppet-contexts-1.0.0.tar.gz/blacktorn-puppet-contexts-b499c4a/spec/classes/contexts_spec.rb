require 'spec_helper'
describe 'contexts' do
  it do
    should contain_package('ContextsForMac').with({
      :source   => 'http://contextsformac.com/releases/Contexts.zip',
      :provider => 'compressed_app'
    })
  end
end
